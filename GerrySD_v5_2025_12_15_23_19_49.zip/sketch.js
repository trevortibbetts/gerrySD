// ===============================
// Project Title: GerrySD v5
// Created by: Trevor Tibbetts
// Notice --> ChatGPT and Claude AI were both used to help create this project
// Link to Pres --> https://docs.google.com/presentation/d/17zHbZFdr9_O9yfaGjbQujOYHBMde1Oq0gnBx1gi17Y0/edit?usp=sharing
// ===============================

// Global map + data
let leafletMap;
let tractsData, boundaryData;

// Leaflet layers
let tractsLayer;
let boundaryLayer;
let drawnLayer;    // user-drawn lines
let districtLayer; // colored districts

// Turf geometry
let countyPolyTurf = null;   // county polygon
let tractCentroids = [];     // [{ feature, point }] point is turf point
let countyArea = 0;

// Choropleth params
let medianDem = 0.5;

// Colors for districts
const districtColors = ['#FE7536', '#45A2F8', '#85F862', '#D620A0', '#EC0000'];

// Store final district data for export
let finalDistrictPolygons = null;
let finalDistrictStats = null;

// -------------------------------
// p5 preload: load GeoJSON files
// -------------------------------
function preload() {
  tractsData = loadJSON('sd_tracts24votes.json');
  boundaryData = loadJSON('sd_boundary_outer.json');
}

// -------------------------------
// p5 setup: initialize map + UI
// -------------------------------
function setup() {
  noCanvas();

  // Create Leaflet map
  leafletMap = L.map('map', {
    zoomControl: true
  });

  // Base map
  L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    maxZoom: 18,
    attribution: '&copy; OpenStreetMap'
  }).addTo(leafletMap);

  // Build county polygon as Turf feature
  countyPolyTurf = buildCountyPolygon(boundaryData);
  countyArea = countyPolyTurf ? turf.area(countyPolyTurf) : 0;

  // Add county boundary layer
  boundaryLayer = L.geoJSON(boundaryData, {
    style: {
      color: '#0000ff',
      weight: 3,
      fillOpacity: 0
    }
  }).addTo(leafletMap);

  // Fit map to county boundary
  if (boundaryLayer) {
    leafletMap.fitBounds(boundaryLayer.getBounds());
  }

  // Precompute median dem for choropleth
  medianDem = computeMedianDem(tractsData);

  // Add tracts layer as red-purple-blue choropleth
  tractsLayer = L.geoJSON(tractsData, {
    style: tractStyle
  }).addTo(leafletMap);

  // Precompute tract centroids with Turf
  buildTractCentroids();

  // Layer for user-drawn lines
  drawnLayer = new L.FeatureGroup();
  leafletMap.addLayer(drawnLayer);

  // Layer for district polygons
  districtLayer = new L.FeatureGroup();
  leafletMap.addLayer(districtLayer);

  // Drawing control (polylines only)
  const drawControl = new L.Control.Draw({
    draw: {
      polygon: false,
      rectangle: false,
      circle: false,
      marker: false,
      circlemarker: false,
      polyline: {
        shapeOptions: {
          color: '#0077ff',
          weight: 4
        }
      }
    },
    edit: {
      featureGroup: drawnLayer,
      edit: true,
      remove: true
    }
  });

  leafletMap.addControl(drawControl);

  // When user creates / edits / deletes lines: recompute districts live
  leafletMap.on(L.Draw.Event.CREATED, function (e) {
    drawnLayer.addLayer(e.layer);
    handleLinesChanged();
  });

  leafletMap.on(L.Draw.Event.EDITED, handleLinesChanged);
  leafletMap.on(L.Draw.Event.DELETED, handleLinesChanged);

  // Hook up buttons
  document.getElementById('validate-btn').addEventListener('click', handleValidate);
  document.getElementById('report-btn').addEventListener('click', handleRunReport);
  document.getElementById('save-btn').addEventListener('click', handleSaveGeoJSON);

  console.log('Built centroids for', tractCentroids.length, 'tracts');
  console.log('GerrySD loaded. Draw up to 4 lines.');
}

function draw() {
  // Not used; Leaflet handles the map
}

// -------------------------------
// Choropleth style for tracts
// -------------------------------
function tractStyle(feature) {
  const props = feature.properties || {};
  const pdem = Number(props.predem);

  let fillColor = '#cccccc';

  if (!isNaN(pdem)) {
    const p = pdem; // assume 0–1

    if (p >= 0.80) {
      fillColor = '#08306B';         // very strong Dem
    } else if (p > medianDem + 0.05) {
      fillColor = '#4292C6';         // Dem leaning
    } else if (Math.abs(p - medianDem) <= 0.05) {
      fillColor = '#9253A2';         // purple band
    } else if (p < medianDem - 0.15) {
      fillColor = '#99000D';         // strong Rep
    } else {
      fillColor = '#FB6A4A';         // Rep leaning
    }
  }

  return {
    color: '#555555',
    weight: 0.2,
    fillOpacity: 0.7,
    fillColor: fillColor
  };
}

// -------------------------------
// Compute median predem
// -------------------------------
function computeMedianDem(geojson) {
  if (!geojson || !geojson.features) return 0.5;
  const vals = [];
  geojson.features.forEach(f => {
    const p = f.properties || {};
    const pdem = Number(p.predem);
    if (!isNaN(pdem)) vals.push(pdem);
  });
  if (vals.length === 0) return 0.5;
  vals.sort((a, b) => a - b);
  const mid = Math.floor(vals.length / 2);
  if (vals.length % 2 === 0) {
    return (vals[mid - 1] + vals[mid]) / 2;
  }
  return vals[mid];
}

// -------------------------------
// Build county polygon as single Turf Polygon
// -------------------------------
function buildCountyPolygon(boundaryGeojson) {
  if (!boundaryGeojson || !boundaryGeojson.features || boundaryGeojson.features.length === 0) {
    return null;
  }

  let poly = null;
  boundaryGeojson.features.forEach(f => {
    if (f.geometry && (f.geometry.type === 'Polygon' || f.geometry.type === 'MultiPolygon')) {
      const thisPoly = turf.feature(f.geometry);
      if (!poly) {
        poly = thisPoly;
      } else {
        try {
          poly = turf.union(poly, thisPoly);
        } catch (e) {
          console.warn('Turf union failed for boundary piece:', e);
        }
      }
    }
  });

  return poly;
}

// -------------------------------
// Precompute tract centroids as Turf points
// -------------------------------
function buildTractCentroids() {
  tractCentroids = [];
  if (!tractsData || !tractsData.features) return;

  tractsData.features.forEach(f => {
    try {
      const c = turf.centroid(f);
      tractCentroids.push({
        feature: f,
        point: c
      });
    } catch (e) {
      console.warn('Failed to compute centroid for tract:', e);
    }
  });
}

// -------------------------------
// Get array of Leaflet polylines
// -------------------------------
function getUserLines() {
  const lines = [];
  drawnLayer.eachLayer(function (layer) {
    if (layer instanceof L.Polyline && !(layer instanceof L.Polygon)) {
      const latLngs = layer.getLatLngs();
      if (latLngs.length >= 2) {
        lines.push(layer);
      }
    }
  });
  return lines;
}

// Convert a Leaflet polyline to a Turf LineString
function polylineToTurf(lineLayer) {
  const latLngs = lineLayer.getLatLngs();
  const coords = latLngs.map(ll => [ll.lng, ll.lat]);
  return turf.lineString(coords);
}

// -------------------------------
// Core: cut polygon with a line, using buffer + difference
// Returns an array of polygons (1 if not actually split)
// -------------------------------
function cutPolygonWithLine(poly, line) {
  try {
    // Make a thin strip around the line (200m wide)
    const buffered = turf.buffer(line, 0.2, { units: 'kilometers' });

    // Subtract the strip from the polygon
    const diff = turf.difference(poly, buffered);

    if (!diff || !diff.geometry) {
      // Nothing left? treat as unsplit to be safe
      return [poly];
    }

    const geom = diff.geometry;

    if (geom.type === 'Polygon') {
      // Still just one polygon -> line didn't really cut it
      return [poly];
    }

    if (geom.type === 'MultiPolygon') {
      // Split into separate polygon features
      return geom.coordinates.map(coords => turf.polygon(coords));
    }

    // Any other geometry type: keep original
    return [poly];
  } catch (e) {
    console.warn('cutPolygonWithLine failed, keeping original polygon:', e);
    return [poly];
  }
}

// -------------------------------
// Build district polygons by cutting county with each line
// -------------------------------
function computeDistrictPolygons(userLines) {
  if (!countyPolyTurf) return [];

  let districts = [countyPolyTurf];

  userLines.forEach(lineLayer => {
    const line = polylineToTurf(lineLayer);
    const newDistricts = [];

    districts.forEach(poly => {
      const pieces = cutPolygonWithLine(poly, line);
      pieces.forEach(p => newDistricts.push(p));
    });

    districts = newDistricts;

    // Filter out tiny slivers (e.g., <0.1% of county area)
    if (countyArea > 0) {
      const threshold = countyArea * 0.001;
      districts = districts.filter(p => {
        try {
          return turf.area(p) > threshold;
        } catch (e) {
          return true;
        }
      });
    }
  });

  return districts;
}

// -------------------------------
// Assign tracts to districts & compute stats
function computeDistrictStats(districtPolys) {
  // Clear districtId on tracts
  if (tractsData && tractsData.features) {
    tractsData.features.forEach(f => {
      f.properties = f.properties || {};
      f.properties.districtId = null;
    });
  }

  const stats = {};
  const numDistricts = districtPolys.length;

  for (let i = 1; i <= numDistricts; i++) {
    stats[i] = {
      districtId: i,
      tracts: 0,
      voteTotal: 0,
      demVotes: 0
    };
  }

  let unassigned = 0;
  const unassignedTracts = [];

  // 1) First pass: normal point-in-polygon
  tractCentroids.forEach(tc => {
    const pt = tc.point;
    const props = tc.feature.properties || {};
    let assigned = false;

    for (let i = 0; i < districtPolys.length; i++) {
      const poly = districtPolys[i];
      try {
        if (turf.booleanPointInPolygon(pt, poly)) {
          const dId = i + 1;
          stats[dId].tracts++;
          const voteTotal = Number(props.vote_tot) || 0;
          const demPct = Number(props.predem) || 0;
          stats[dId].voteTotal += voteTotal;
          stats[dId].demVotes += voteTotal * demPct;
          tc.feature.properties.districtId = dId;
          assigned = true;
          break;
        }
      } catch (e) {
        console.warn('booleanPointInPolygon failed:', e);
      }
    }

    if (!assigned) {
      unassigned++;
      unassignedTracts.push(tc);
    }
  });

  // 2) Second pass: snap any leftovers to the nearest district centroid
  if (unassigned > 0 && districtPolys.length > 0) {
    const districtCenters = districtPolys.map(poly => {
      try {
        return turf.centroid(poly);
      } catch (e) {
        return null;
      }
    });

    unassignedTracts.forEach(tc => {
      const pt = tc.point;
      const props = tc.feature.properties || {};

      let bestIdx = -1;
      let bestDist = Infinity;

      districtCenters.forEach((center, idx) => {
        if (!center) return;
        try {
          const d = turf.distance(pt, center, { units: 'kilometers' });
          if (d < bestDist) {
            bestDist = d;
            bestIdx = idx;
          }
        } catch (e) {
          // ignore
        }
      });

      if (bestIdx >= 0) {
        const dId = bestIdx + 1;
        const voteTotal = Number(props.vote_tot) || 0;
        const demPct = Number(props.predem) || 0;

        stats[dId].tracts++;
        stats[dId].voteTotal += voteTotal;
        stats[dId].demVotes += voteTotal * demPct;
        tc.feature.properties.districtId = dId;
      }
    });

    // After snapping, treat as fully assigned
    unassigned = 0;
  }

  return { stats, unassigned };
}

// -------------------------------
// Redraw district polygons and live stats
// -------------------------------
function recomputeAndRenderDistricts() {
  const userLines = getUserLines();
  const districts = computeDistrictPolygons(userLines);

  districtLayer.clearLayers();

  if (!districts || districts.length === 0) {
    updateLiveReport(null, null, userLines.length);
    return;
  }

  // Draw polygons
  districts.forEach((poly, idx) => {
    poly.properties = poly.properties || {};
    poly.properties.districtId = idx + 1;

    L.geoJSON(poly, {
      style: {
        color: '#000000',
        weight: 1.2,
        fillOpacity: 0.35,
        fillColor: districtColors[idx % districtColors.length]
      }
    }).addTo(districtLayer);
  });

  const { stats, unassigned } = computeDistrictStats(districts);
  updateLiveReport(stats, unassigned, userLines.length);
}

// -------------------------------
// Handle line changes (create/edit/delete)
// -------------------------------
function handleLinesChanged() {
  const statusBox = document.getElementById('validation-status');
  if (statusBox) statusBox.style.display = 'none';

  recomputeAndRenderDistricts();
}

// -------------------------------
// Validation button handler
// -------------------------------
function handleValidate() {
  const userLines = getUserLines();

  if (userLines.length !== 4) {
    showValidationStatus(
      false,
      `Invalid: You have ${userLines.length} line(s). Draw exactly 4 lines.`
    );
    return;
  }

  const districts = computeDistrictPolygons(userLines);

  if (!districts || districts.length !== 5) {
    showValidationStatus(
      false,
      `Invalid: Your 4 lines produce ${districts.length} district region(s) instead of 5. ` +
      `Adjust your lines so they cleanly divide the county into 5 pieces.`
    );
    return;
  }

  const { stats, unassigned } = computeDistrictStats(districts);

  if (unassigned > 0) {
    showValidationStatus(
      false,
      `Invalid: ${unassigned} tract(s) are not assigned to any district. ` +
      `Make sure your lines fully cover the county without leaving gaps.`
    );
    return;
  }

  showValidationStatus(
    true,
    'Valid! 4 lines successfully split the county into 5 districts and all tracts are assigned.'
  );

  // Emphasize districts
  districtLayer.clearLayers();
  districts.forEach((poly, idx) => {
    L.geoJSON(poly, {
      style: {
        color: '#000000',
        weight: 1.5,
        fillOpacity: 0.45,
        fillColor: districtColors[idx % districtColors.length]
      }
    }).addTo(districtLayer);
  });

  updateLiveReport(stats, 0, userLines.length);
}

// -------------------------------
// Run Report - lock in stats & districts
function handleRunReport() {
  const userLines = getUserLines();

  if (userLines.length !== 4) {
    showReport(false, 'Need exactly 4 lines. Draw or delete lines, then validate again.');
    // Hide save button
    document.getElementById('save-btn').style.display = 'none';
    return;
  }

  const districts = computeDistrictPolygons(userLines);

  if (!districts || districts.length !== 5) {
    showReport(false, `Your 4 lines produce ${districts.length} districts instead of 5. Fix this and validate again.`);
    document.getElementById('save-btn').style.display = 'none';
    return;
  }

  const { stats, unassigned } = computeDistrictStats(districts);

  if (unassigned > 0) {
    showReport(false, `${unassigned} tract(s) are not assigned to any district. Adjust your lines to cover the whole county.`);
    document.getElementById('save-btn').style.display = 'none';
    return;
  }

  // Store data for export
  finalDistrictPolygons = districts;
  finalDistrictStats = stats;

  // 1) Draw district outlines only (no heavy fill),
  //    so the census tracts can be the main "shape" people see.
  districtLayer.clearLayers();
  districts.forEach((poly, idx) => {
    L.geoJSON(poly, {
      style: {
        color: '#000000',
        weight: 2,
        fillOpacity: 0,     // transparent fill
        fillColor: 'transparent'
      }
    }).addTo(districtLayer);
  });

  // 2) Color census tracts by their assigned district
  applyDistrictColorsToTracts();

  // 3) Show final numeric report
  showReport(true, null, stats);

  // 4) Show save button
  document.getElementById('save-btn').style.display = 'inline-block';
}

// -------------------------------
// Save as GeoJSON handler
// -------------------------------
function handleSaveGeoJSON() {
  if (!finalDistrictPolygons || !finalDistrictStats) {
    alert('Please run the report first before saving.');
    return;
  }

  // Create GeoJSON FeatureCollection
  const features = finalDistrictPolygons.map((poly, idx) => {
    const dId = idx + 1;
    const stats = finalDistrictStats[dId];
    const demPct = stats.voteTotal > 0 ? (stats.demVotes / stats.voteTotal * 100) : 0;

    return {
      type: 'Feature',
      properties: {
        districtId: dId,
        districtName: `District ${dId}`,
        tracts: stats.tracts,
        totalVotes: stats.voteTotal,
        demVotes: stats.demVotes,
        demPercentage: parseFloat(demPct.toFixed(2)),
        color: districtColors[(dId - 1) % districtColors.length]
      },
      geometry: poly.geometry
    };
  });

  const geojson = {
    type: 'FeatureCollection',
    features: features
  };

  // Convert to JSON string
  const jsonString = JSON.stringify(geojson, null, 2);

  // Create blob and download
  const blob = new Blob([jsonString], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  
  const a = document.createElement('a');
  a.href = url;
  a.download = 'gerrysd_districts.geojson';
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);

  console.log('GeoJSON saved successfully');
}

// -------------------------------
// Show validation status
// -------------------------------
function showValidationStatus(isValid, message) {
  const statusBox = document.getElementById('validation-status');
  if (!statusBox) return;

  statusBox.style.display = 'block';
  statusBox.className = 'status-box ' + (isValid ? 'valid' : 'invalid');

  const icon = isValid
    ? '<svg class="status-icon" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" style="color: #16a34a;"></path></svg>'
    : '<svg class="status-icon" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" style="color: #dc2626;"></path></svg>';

  statusBox.innerHTML = `
    ${icon}
    <div class="status-content">
      <p class="status-title">${isValid ? 'Valid Configuration' : 'Invalid Configuration'}</p>
      <p class="status-message">${message}</p>
    </div>
  `;
}

// -------------------------------
// Live report update (used by recompute) - UPDATED LAYOUT
// -------------------------------
function updateLiveReport(statsOrNull, unassigned, numLines) {
  const reportContainer = document.getElementById('report-container');
  const reportContent = document.getElementById('report-content');
  if (!reportContainer || !reportContent) return;

  reportContainer.style.display = 'block';

  if (!statsOrNull) {
    reportContent.innerHTML = `
      <div class="info-box">
        <p class="info-text">
          Draw up to 4 lines. As you draw, the county will be split into districts and stats will appear here.
          Currently you have ${numLines} line(s).
        </p>
      </div>
    `;
    return;
  }

  const stats = statsOrNull;
  let html = '';

  const districtIds = Object.keys(stats).map(Number).sort((a, b) => a - b);

  html += `<p>Live view: ${districtIds.length} district region(s) from ${numLines} line(s)` +
    (typeof unassigned === 'number' && unassigned > 0
      ? `, ${unassigned} tract(s) unassigned`
      : '') +
    `.</p>`;

  districtIds.forEach(id => {
    const d = stats[id];
    const demPct = d.voteTotal > 0 ? (d.demVotes / d.voteTotal * 100) : 0;
    html += `
      <div class="district-card">
        <div class="district-name-badge" style="background:${districtColors[(id - 1) % districtColors.length]};">
          District ${id}
        </div>
        <div class="district-stat-line">
          <span class="stat-label">Dem Vote Share:</span>
          <span class="stat-value">${demPct.toFixed(1)}%</span>
        </div>
        <div class="district-stat-line">
          <span class="stat-label">Tracts:</span>
          <span class="stat-value">${d.tracts}</span>
        </div>
        <div class="district-stat-line">
          <span class="stat-label">Votes:</span>
          <span class="stat-value">${d.voteTotal.toLocaleString()}</span>
        </div>
      </div>
    `;
  });

  reportContent.innerHTML = html;
}

// -------------------------------
// After final Run Report: color census tracts by district
// -------------------------------
function applyDistrictColorsToTracts() {
  if (!tractsLayer) return;

  tractsLayer.setStyle(function (feature) {
    const props = feature.properties || {};
    const dId = props.districtId;

    // If somehow unassigned, keep it muted
    if (dId == null) {
      return {
        color: '#555555',
        weight: 0.3,
        fillOpacity: 0.2,
        fillColor: '#cccccc'
      };
    }

    // District-based coloring
    const color = districtColors[(dId - 1) % districtColors.length];

    return {
      color: '#333333',        // tract border
      weight: 0.3,
      fillOpacity: 0.85,
      fillColor: color
    };
  });
}


// -------------------------------
// Final report (after Run Report) - UPDATED LAYOUT
// -------------------------------
function showReport(success, errorMessage, stats) {
  const reportContainer = document.getElementById('report-container');
  const reportContent = document.getElementById('report-content');

  if (!reportContainer || !reportContent) return;

  reportContainer.style.display = 'block';

  if (!success) {
    reportContent.innerHTML = `
      <div class="error-box">
        <p class="error-text">${errorMessage}</p>
      </div>
    `;
    return;
  }

  const districtIds = Object.keys(stats).map(Number).sort((a, b) => a - b);
  let html = '<p>Final districts: ' + districtIds.length + '.</p>';

  districtIds.forEach(id => {
    const d = stats[id];
    const demPct = d.voteTotal > 0 ? (d.demVotes / d.voteTotal * 100) : 0;
    html += `
      <div class="district-card">
        <div class="district-name-badge" style="background:${districtColors[(id - 1) % districtColors.length]};">
          District ${id}
        </div>
        <div class="district-stat-line">
          <span class="stat-label">Dem Vote Share:</span>
          <span class="stat-value">${demPct.toFixed(1)}%</span>
        </div>
        <div class="district-stat-line">
          <span class="stat-label">Tracts:</span>
          <span class="stat-value">${d.tracts}</span>
        </div>
        <div class="district-stat-line">
          <span class="stat-label">Votes:</span>
          <span class="stat-value">${d.voteTotal.toLocaleString()}</span>
        </div>
      </div>
    `;
  });

  reportContent.innerHTML = html;
}